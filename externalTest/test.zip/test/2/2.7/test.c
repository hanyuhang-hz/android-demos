#include <stdio.h>
#define LOG_TAG "HYH"
#include <utils/Log.h>
#include <call.h>

int main() {
    call();
    printf("hyh test! \n");
    ALOGE("test!");
    return 0;
}
