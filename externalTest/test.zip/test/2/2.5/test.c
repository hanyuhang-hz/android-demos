#include <stdio.h>
#define LOG_TAG "HYH"
#include <utils/Log.h>

int main() {
    printf("hyh test! \n");
    ALOGE("test!");
    return 0;
}
