#include <stdio.h>

// extern:可置于变量或者函数前，以表示变量或者函数的定义在其他的文件中
extern void call();

int main() {
    call();
    printf("hyh test! \n");
    return 0;
}
