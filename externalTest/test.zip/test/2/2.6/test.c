#include <stdio.h>
#define LOG_TAG "HYH"
#include <utils/Log.h>

// extern:可置于变量或者函数前，以表示变量或者函数的定义在其他的文件中
extern void call();

int main() {
    call();
    printf("hyh test! \n");
    ALOGE("test!");
    return 0;
}
