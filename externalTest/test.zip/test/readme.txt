Android.mk基础语法学习:
如何使用:
1 将test目录拷贝到aosp代码的external目录
2 source build/envsetup.sh
  lunch xxx
  mmm external/test/1/
  ...
